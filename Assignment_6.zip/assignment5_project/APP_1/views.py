from django.shortcuts import render

# Create your views here.
def my_name(request):
    return render(request,'app_1/my_name.html')
def study_status(request):
    return render(request,'app_1/study_status.html')