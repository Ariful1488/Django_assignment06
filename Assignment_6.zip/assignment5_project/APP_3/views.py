from django.shortcuts import render

# Create your views here.
def ai_learning(request):
    return render(request,'app_3/ai_learning.html')
def python_learning(request):
    return render(request,'app_3/python_learning.html')