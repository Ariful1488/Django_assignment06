from django.urls import path
from . import views

urlpatterns = [
    path('ai/',views.ai_learning),
    path('py/',views.python_learning),
]
