from django.urls import path
from . import views

urlpatterns = [
    path('ap/',views.ai_part),
    path('hb/',views.hobby)
]
