from django.shortcuts import render

# Create your views here.
def hobby(request):
    return render(request,'app_2/hobby.html')
def ai_part(request):
    return render(request,'app_2/ai_part.html')